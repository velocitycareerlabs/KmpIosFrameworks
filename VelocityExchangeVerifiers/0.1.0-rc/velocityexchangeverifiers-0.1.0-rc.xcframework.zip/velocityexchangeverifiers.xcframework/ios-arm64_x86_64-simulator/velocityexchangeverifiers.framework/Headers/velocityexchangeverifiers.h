#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class VelocityexchangeverifiersCnf, VelocityexchangeverifiersCnfCompanion, VelocityexchangeverifiersCredentialEndpointResponse, VelocityexchangeverifiersCredentialEndpointResponseCompanion, VelocityexchangeverifiersCredentialIssuerMetadata, VelocityexchangeverifiersCredentialJwtParser, VelocityexchangeverifiersCredentialVerifiers, VelocityexchangeverifiersErrorCode, VelocityexchangeverifiersJwtHeader, VelocityexchangeverifiersJwtHeaderCompanion, VelocityexchangeverifiersJwtHeaderSerializer, VelocityexchangeverifiersJwtPayload, VelocityexchangeverifiersJwtPayloadCompanion, VelocityexchangeverifiersJwtPayloadSerializer, VelocityexchangeverifiersKotlinArray<T>, VelocityexchangeverifiersKotlinEnum<E>, VelocityexchangeverifiersKotlinEnumCompanion, VelocityexchangeverifiersKotlinException, VelocityexchangeverifiersKotlinIllegalArgumentException, VelocityexchangeverifiersKotlinNothing, VelocityexchangeverifiersKotlinRuntimeException, VelocityexchangeverifiersKotlinThrowable, VelocityexchangeverifiersKotlinx_serialization_coreSerialKind, VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule, VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode, VelocityexchangeverifiersKotlinx_serialization_jsonJson, VelocityexchangeverifiersKotlinx_serialization_jsonJsonConfiguration, VelocityexchangeverifiersKotlinx_serialization_jsonJsonDefault, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElementCompanion, VelocityexchangeverifiersVcClaims, VelocityexchangeverifiersVcClaimsCompanion, VelocityexchangeverifiersVerificationContext, VelocityexchangeverifiersVerificationError, VelocityexchangeverifiersVerifiersApiCompanion, VelocityexchangeverifiersW3CCredentialJwtV1, VelocityexchangeverifiersW3CCredentialJwtV1Companion;

@protocol VelocityexchangeverifiersKotlinAnnotation, VelocityexchangeverifiersKotlinComparable, VelocityexchangeverifiersKotlinIterator, VelocityexchangeverifiersKotlinKAnnotatedElement, VelocityexchangeverifiersKotlinKClass, VelocityexchangeverifiersKotlinKClassifier, VelocityexchangeverifiersKotlinKDeclarationContainer, VelocityexchangeverifiersKotlinx_serialization_coreCompositeDecoder, VelocityexchangeverifiersKotlinx_serialization_coreCompositeEncoder, VelocityexchangeverifiersKotlinx_serialization_coreDecoder, VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy, VelocityexchangeverifiersKotlinx_serialization_coreEncoder, VelocityexchangeverifiersKotlinx_serialization_coreKSerializer, VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor, VelocityexchangeverifiersKotlinx_serialization_coreSerialFormat, VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy, VelocityexchangeverifiersKotlinx_serialization_coreSerializersModuleCollector, VelocityexchangeverifiersKotlinx_serialization_coreStringFormat, VelocityexchangeverifiersKotlinx_serialization_jsonJsonNamingStrategy;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface VelocityexchangeverifiersBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface VelocityexchangeverifiersBase (VelocityexchangeverifiersBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface VelocityexchangeverifiersMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface VelocityexchangeverifiersMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorVelocityexchangeverifiersKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface VelocityexchangeverifiersNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface VelocityexchangeverifiersByte : VelocityexchangeverifiersNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface VelocityexchangeverifiersUByte : VelocityexchangeverifiersNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface VelocityexchangeverifiersShort : VelocityexchangeverifiersNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface VelocityexchangeverifiersUShort : VelocityexchangeverifiersNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface VelocityexchangeverifiersInt : VelocityexchangeverifiersNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface VelocityexchangeverifiersUInt : VelocityexchangeverifiersNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface VelocityexchangeverifiersLong : VelocityexchangeverifiersNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface VelocityexchangeverifiersULong : VelocityexchangeverifiersNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface VelocityexchangeverifiersFloat : VelocityexchangeverifiersNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface VelocityexchangeverifiersDouble : VelocityexchangeverifiersNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface VelocityexchangeverifiersBoolean : VelocityexchangeverifiersNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialJwtParser")))
@interface VelocityexchangeverifiersCredentialJwtParser : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)credentialJwtParser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersCredentialJwtParser *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of SerializationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (VelocityexchangeverifiersCredentialEndpointResponse * _Nullable)parseCredentialEndpointResponseJsonString:(NSString *)jsonString error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("parseCredentialEndpointResponse(jsonString:)")));
- (VelocityexchangeverifiersCredentialEndpointResponse * _Nullable)parseCredentialEndpointResponseOrNullJsonString:(NSString *)jsonString __attribute__((swift_name("parseCredentialEndpointResponseOrNull(jsonString:)")));

/**
 * @note This method converts instances of SerializationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (VelocityexchangeverifiersW3CCredentialJwtV1 * _Nullable)parseCredentialJwtJsonString:(NSString *)jsonString error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("parseCredentialJwt(jsonString:)")));
- (VelocityexchangeverifiersW3CCredentialJwtV1 * _Nullable)parseCredentialJwtOrNullJsonString:(NSString *)jsonString __attribute__((swift_name("parseCredentialJwtOrNull(jsonString:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VerifiersApi")))
@interface VelocityexchangeverifiersVerifiersApi : VelocityexchangeverifiersBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) VelocityexchangeverifiersVerifiersApiCompanion *companion __attribute__((swift_name("companion")));
- (NSArray<VelocityexchangeverifiersVerificationError *> *)verifyCredentialEndpointResponseResponse:(VelocityexchangeverifiersCredentialEndpointResponse *)response context:(VelocityexchangeverifiersVerificationContext *)context verifiers:(VelocityexchangeverifiersCredentialVerifiers *)verifiers __attribute__((swift_name("verifyCredentialEndpointResponse(response:context:verifiers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VerifiersApi.Companion")))
@interface VelocityexchangeverifiersVerifiersApiCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersVerifiersApiCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) VelocityexchangeverifiersCredentialVerifiers *defaultCredentialVerifiers __attribute__((swift_name("defaultCredentialVerifiers")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Cnf")))
@interface VelocityexchangeverifiersCnf : VelocityexchangeverifiersBase
- (instancetype)initWithClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims __attribute__((swift_name("init(claims:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithJson:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)json __attribute__((swift_name("init(json:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersCnfCompanion *companion __attribute__((swift_name("companion")));
- (VelocityexchangeverifiersCnf *)doCopyClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims __attribute__((swift_name("doCopy(claims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *claims __attribute__((swift_name("claims")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> * _Nullable jwk __attribute__((swift_name("jwk")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Cnf.Companion")))
@interface VelocityexchangeverifiersCnfCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersCnfCompanion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialEndpointResponse")))
@interface VelocityexchangeverifiersCredentialEndpointResponse : VelocityexchangeverifiersBase
- (instancetype)initWithClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims __attribute__((swift_name("init(claims:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersCredentialEndpointResponseCompanion *companion __attribute__((swift_name("companion")));
- (VelocityexchangeverifiersCredentialEndpointResponse *)doCopyClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims __attribute__((swift_name("doCopy(claims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *claims __attribute__((swift_name("claims")));
@property (readonly) NSArray<VelocityexchangeverifiersW3CCredentialJwtV1 *> * _Nullable credentials __attribute__((swift_name("credentials")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialEndpointResponse.Companion")))
@interface VelocityexchangeverifiersCredentialEndpointResponseCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersCredentialEndpointResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialIssuerMetadata")))
@interface VelocityexchangeverifiersCredentialIssuerMetadata : VelocityexchangeverifiersBase
- (instancetype)initWithIss:(NSString *)iss credentialIssuer:(NSString * _Nullable)credentialIssuer __attribute__((swift_name("init(iss:credentialIssuer:)"))) __attribute__((objc_designated_initializer));
- (VelocityexchangeverifiersCredentialIssuerMetadata *)doCopyIss:(NSString *)iss credentialIssuer:(NSString * _Nullable)credentialIssuer __attribute__((swift_name("doCopy(iss:credentialIssuer:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable credentialIssuer __attribute__((swift_name("credentialIssuer")));
@property (readonly) NSString *iss __attribute__((swift_name("iss")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialVerifiers")))
@interface VelocityexchangeverifiersCredentialVerifiers : VelocityexchangeverifiersBase
- (instancetype)initWithAlgIsSupported:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))algIsSupported credentialSchema:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))credentialSchema credentialStatus:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))credentialStatus issClaimMatchesEitherMetadataOrCredentialIssuer:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))issClaimMatchesEitherMetadataOrCredentialIssuer issClaimMatchesMetadata:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))issClaimMatchesMetadata kidClaimIsVelocityV2:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))kidClaimIsVelocityV2 subIsDidJwkOrCnf:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))subIsDidJwkOrCnf __attribute__((swift_name("init(algIsSupported:credentialSchema:credentialStatus:issClaimMatchesEitherMetadataOrCredentialIssuer:issClaimMatchesMetadata:kidClaimIsVelocityV2:subIsDidJwkOrCnf:)"))) __attribute__((objc_designated_initializer));
- (VelocityexchangeverifiersCredentialVerifiers *)doCopyAlgIsSupported:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))algIsSupported credentialSchema:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))credentialSchema credentialStatus:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))credentialStatus issClaimMatchesEitherMetadataOrCredentialIssuer:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))issClaimMatchesEitherMetadataOrCredentialIssuer issClaimMatchesMetadata:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))issClaimMatchesMetadata kidClaimIsVelocityV2:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))kidClaimIsVelocityV2 subIsDidJwkOrCnf:(VelocityexchangeverifiersVerificationError * _Nullable (^)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *))subIsDidJwkOrCnf __attribute__((swift_name("doCopy(algIsSupported:credentialSchema:credentialStatus:issClaimMatchesEitherMetadataOrCredentialIssuer:issClaimMatchesMetadata:kidClaimIsVelocityV2:subIsDidJwkOrCnf:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^algIsSupported)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("algIsSupported")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^credentialSchema)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("credentialSchema")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^credentialStatus)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("credentialStatus")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^issClaimMatchesEitherMetadataOrCredentialIssuer)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("issClaimMatchesEitherMetadataOrCredentialIssuer")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^issClaimMatchesMetadata)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("issClaimMatchesMetadata")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^kidClaimIsVelocityV2)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("kidClaimIsVelocityV2")));
@property (readonly) VelocityexchangeverifiersVerificationError * _Nullable (^subIsDidJwkOrCnf)(VelocityexchangeverifiersW3CCredentialJwtV1 *, VelocityexchangeverifiersVerificationContext *) __attribute__((swift_name("subIsDidJwkOrCnf")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol VelocityexchangeverifiersKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface VelocityexchangeverifiersKotlinEnum<E> : VelocityexchangeverifiersBase <VelocityexchangeverifiersKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorCode")))
@interface VelocityexchangeverifiersErrorCode : VelocityexchangeverifiersKotlinEnum<VelocityexchangeverifiersErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) VelocityexchangeverifiersErrorCode *invalidAlg __attribute__((swift_name("invalidAlg")));
@property (class, readonly) VelocityexchangeverifiersErrorCode *invalidKid __attribute__((swift_name("invalidKid")));
@property (class, readonly) VelocityexchangeverifiersErrorCode *subOrCnfMissing __attribute__((swift_name("subOrCnfMissing")));
@property (class, readonly) VelocityexchangeverifiersErrorCode *unexpectedCredentialPayloadIss __attribute__((swift_name("unexpectedCredentialPayloadIss")));
@property (class, readonly) VelocityexchangeverifiersErrorCode *unexpectedCredentialIssuerMetadata __attribute__((swift_name("unexpectedCredentialIssuerMetadata")));
@property (class, readonly) VelocityexchangeverifiersErrorCode *missingCredentialStatus __attribute__((swift_name("missingCredentialStatus")));
@property (class, readonly) VelocityexchangeverifiersErrorCode *missingCredentialSchema __attribute__((swift_name("missingCredentialSchema")));
+ (VelocityexchangeverifiersKotlinArray<VelocityexchangeverifiersErrorCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<VelocityexchangeverifiersErrorCode *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *code __attribute__((swift_name("code")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=io/velocitycareerlabs/velocityexchangeverifiers/impl/serializers/JwtHeaderSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtHeader")))
@interface VelocityexchangeverifiersJwtHeader : VelocityexchangeverifiersBase
- (instancetype)initWithClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims alg:(NSString * _Nullable)alg kid:(NSString * _Nullable)kid typ:(NSString * _Nullable)typ __attribute__((swift_name("init(claims:alg:kid:typ:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersJwtHeaderCompanion *companion __attribute__((swift_name("companion")));
- (VelocityexchangeverifiersJwtHeader *)doCopyClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims alg:(NSString * _Nullable)alg kid:(NSString * _Nullable)kid typ:(NSString * _Nullable)typ __attribute__((swift_name("doCopy(claims:alg:kid:typ:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable alg __attribute__((swift_name("alg")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *claims __attribute__((swift_name("claims")));
@property (readonly) NSString * _Nullable kid __attribute__((swift_name("kid")));
@property (readonly) NSString * _Nullable typ __attribute__((swift_name("typ")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtHeader.Companion")))
@interface VelocityexchangeverifiersJwtHeaderCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersJwtHeaderCompanion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=io/velocitycareerlabs/velocityexchangeverifiers/impl/serializers/JwtPayloadSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtPayload")))
@interface VelocityexchangeverifiersJwtPayload : VelocityexchangeverifiersBase
- (instancetype)initWithClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims iss:(NSString * _Nullable)iss sub:(NSString * _Nullable)sub cnf:(VelocityexchangeverifiersCnf * _Nullable)cnf vc:(VelocityexchangeverifiersVcClaims * _Nullable)vc __attribute__((swift_name("init(claims:iss:sub:cnf:vc:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersJwtPayloadCompanion *companion __attribute__((swift_name("companion")));
- (VelocityexchangeverifiersJwtPayload *)doCopyClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims iss:(NSString * _Nullable)iss sub:(NSString * _Nullable)sub cnf:(VelocityexchangeverifiersCnf * _Nullable)cnf vc:(VelocityexchangeverifiersVcClaims * _Nullable)vc __attribute__((swift_name("doCopy(claims:iss:sub:cnf:vc:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *claims __attribute__((swift_name("claims")));
@property (readonly) VelocityexchangeverifiersCnf * _Nullable cnf __attribute__((swift_name("cnf")));
@property (readonly) NSString * _Nullable iss __attribute__((swift_name("iss")));
@property (readonly) NSString * _Nullable sub __attribute__((swift_name("sub")));
@property (readonly) VelocityexchangeverifiersVcClaims * _Nullable vc __attribute__((swift_name("vc")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtPayload.Companion")))
@interface VelocityexchangeverifiersJwtPayloadCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersJwtPayloadCompanion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VcClaims")))
@interface VelocityexchangeverifiersVcClaims : VelocityexchangeverifiersBase
- (instancetype)initWithClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims __attribute__((swift_name("init(claims:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithJson:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)json __attribute__((swift_name("init(json:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersVcClaimsCompanion *companion __attribute__((swift_name("companion")));
- (VelocityexchangeverifiersVcClaims *)doCopyClaims:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)claims __attribute__((swift_name("doCopy(claims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *claims __attribute__((swift_name("claims")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> * _Nullable credentialSchema __attribute__((swift_name("credentialSchema")));
@property (readonly) NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> * _Nullable credentialStatus __attribute__((swift_name("credentialStatus")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VcClaims.Companion")))
@interface VelocityexchangeverifiersVcClaimsCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersVcClaimsCompanion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VerificationContext")))
@interface VelocityexchangeverifiersVerificationContext : VelocityexchangeverifiersBase
- (instancetype)initWithCredentialIssuerMetadata:(VelocityexchangeverifiersCredentialIssuerMetadata * _Nullable)credentialIssuerMetadata response:(id _Nullable)response path:(NSArray<id> * _Nullable)path __attribute__((swift_name("init(credentialIssuerMetadata:response:path:)"))) __attribute__((objc_designated_initializer));
- (VelocityexchangeverifiersVerificationContext *)doCopyCredentialIssuerMetadata:(VelocityexchangeverifiersCredentialIssuerMetadata * _Nullable)credentialIssuerMetadata response:(id _Nullable)response path:(NSArray<id> * _Nullable)path __attribute__((swift_name("doCopy(credentialIssuerMetadata:response:path:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) VelocityexchangeverifiersCredentialIssuerMetadata * _Nullable credentialIssuerMetadata __attribute__((swift_name("credentialIssuerMetadata")));
@property (readonly) NSArray<id> * _Nullable path __attribute__((swift_name("path")));
@property (readonly) id _Nullable response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VerificationError")))
@interface VelocityexchangeverifiersVerificationError : VelocityexchangeverifiersBase
- (instancetype)initWithCode:(VelocityexchangeverifiersErrorCode *)code message:(NSString *)message path:(NSArray<id> * _Nullable)path __attribute__((swift_name("init(code:message:path:)"))) __attribute__((objc_designated_initializer));
- (VelocityexchangeverifiersVerificationError *)doCopyCode:(VelocityexchangeverifiersErrorCode *)code message:(NSString *)message path:(NSArray<id> * _Nullable)path __attribute__((swift_name("doCopy(code:message:path:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) VelocityexchangeverifiersErrorCode *code __attribute__((swift_name("code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSArray<id> * _Nullable path __attribute__((swift_name("path")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("W3CCredentialJwtV1")))
@interface VelocityexchangeverifiersW3CCredentialJwtV1 : VelocityexchangeverifiersBase
- (instancetype)initWithHeader:(VelocityexchangeverifiersJwtHeader * _Nullable)header payload:(VelocityexchangeverifiersJwtPayload *)payload __attribute__((swift_name("init(header:payload:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) VelocityexchangeverifiersW3CCredentialJwtV1Companion *companion __attribute__((swift_name("companion")));
- (VelocityexchangeverifiersW3CCredentialJwtV1 *)doCopyHeader:(VelocityexchangeverifiersJwtHeader * _Nullable)header payload:(VelocityexchangeverifiersJwtPayload *)payload __attribute__((swift_name("doCopy(header:payload:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) VelocityexchangeverifiersJwtHeader * _Nullable header __attribute__((swift_name("header")));
@property (readonly) VelocityexchangeverifiersJwtPayload *payload __attribute__((swift_name("payload")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("W3CCredentialJwtV1.Companion")))
@interface VelocityexchangeverifiersW3CCredentialJwtV1Companion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersW3CCredentialJwtV1Companion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<VelocityexchangeverifiersKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<VelocityexchangeverifiersKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreKSerializer <VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy, VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtHeaderSerializer")))
@interface VelocityexchangeverifiersJwtHeaderSerializer : VelocityexchangeverifiersBase <VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)jwtHeaderSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersJwtHeaderSerializer *shared __attribute__((swift_name("shared")));
- (VelocityexchangeverifiersJwtHeader *)deserializeDecoder:(id<VelocityexchangeverifiersKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<VelocityexchangeverifiersKotlinx_serialization_coreEncoder>)encoder value:(VelocityexchangeverifiersJwtHeader *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtPayloadSerializer")))
@interface VelocityexchangeverifiersJwtPayloadSerializer : VelocityexchangeverifiersBase <VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)jwtPayloadSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersJwtPayloadSerializer *shared __attribute__((swift_name("shared")));
- (VelocityexchangeverifiersJwtPayload *)deserializeDecoder:(id<VelocityexchangeverifiersKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<VelocityexchangeverifiersKotlinx_serialization_coreEncoder>)encoder value:(VelocityexchangeverifiersJwtPayload *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement : VelocityexchangeverifiersBase
@property (class, readonly, getter=companion) VelocityexchangeverifiersKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

@interface VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement (Extensions)
- (id _Nullable)decodeAsJson:(VelocityexchangeverifiersKotlinx_serialization_jsonJson *)json __attribute__((swift_name("decodeAs(json:)")));
- (id _Nullable)decodeAsOrNullJson:(VelocityexchangeverifiersKotlinx_serialization_jsonJson *)json __attribute__((swift_name("decodeAsOrNull(json:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MapExtensionsKt")))
@interface VelocityexchangeverifiersMapExtensionsKt : VelocityexchangeverifiersBase
+ (VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *)encodeAsJsonElement:(id _Nullable)receiver __attribute__((swift_name("encodeAsJsonElement(_:)")));
+ (NSString * _Nullable)getString:(NSDictionary<NSString *, VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *> *)receiver key:(NSString *)key __attribute__((swift_name("getString(_:key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform_iosKt")))
@interface VelocityexchangeverifiersPlatform_iosKt : VelocityexchangeverifiersBase
+ (NSString *)platform __attribute__((swift_name("platform()")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface VelocityexchangeverifiersKotlinThrowable : VelocityexchangeverifiersBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (VelocityexchangeverifiersKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) VelocityexchangeverifiersKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface VelocityexchangeverifiersKotlinException : VelocityexchangeverifiersKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface VelocityexchangeverifiersKotlinRuntimeException : VelocityexchangeverifiersKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalArgumentException")))
@interface VelocityexchangeverifiersKotlinIllegalArgumentException : VelocityexchangeverifiersKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationException")))
@interface VelocityexchangeverifiersKotlinx_serialization_coreSerializationException : VelocityexchangeverifiersKotlinIllegalArgumentException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(VelocityexchangeverifiersKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface VelocityexchangeverifiersKotlinEnumCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface VelocityexchangeverifiersKotlinArray<T> : VelocityexchangeverifiersBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(VelocityexchangeverifiersInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<VelocityexchangeverifiersKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreEncoder
@required
- (id<VelocityexchangeverifiersKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<VelocityexchangeverifiersKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<VelocityexchangeverifiersKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreDecoder
@required
- (id<VelocityexchangeverifiersKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (VelocityexchangeverifiersKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface VelocityexchangeverifiersKotlinx_serialization_jsonJsonElementCompanion : VelocityexchangeverifiersBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreSerialFormat
@required
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreStringFormat <VelocityexchangeverifiersKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface VelocityexchangeverifiersKotlinx_serialization_jsonJson : VelocityexchangeverifiersBase <VelocityexchangeverifiersKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) VelocityexchangeverifiersKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringValue:(id _Nullable)value __attribute__((swift_name("encodeToString(value:)")));
- (NSString *)encodeToStringSerializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (VelocityexchangeverifiersKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol VelocityexchangeverifiersKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule : VelocityexchangeverifiersBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<VelocityexchangeverifiersKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<VelocityexchangeverifiersKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<VelocityexchangeverifiersKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol VelocityexchangeverifiersKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface VelocityexchangeverifiersKotlinx_serialization_coreSerialKind : VelocityexchangeverifiersBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<VelocityexchangeverifiersKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) VelocityexchangeverifiersKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface VelocityexchangeverifiersKotlinNothing : VelocityexchangeverifiersBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface VelocityexchangeverifiersKotlinx_serialization_jsonJsonDefault : VelocityexchangeverifiersKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) VelocityexchangeverifiersKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface VelocityexchangeverifiersKotlinx_serialization_jsonJsonConfiguration : VelocityexchangeverifiersBase
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowComments __attribute__((swift_name("allowComments")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL allowTrailingComma __attribute__((swift_name("allowTrailingComma")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *classDiscriminatorMode __attribute__((swift_name("classDiscriminatorMode")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL decodeEnumsCaseInsensitive __attribute__((swift_name("decodeEnumsCaseInsensitive")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<VelocityexchangeverifiersKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol VelocityexchangeverifiersKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<VelocityexchangeverifiersKotlinKClass>)kClass provider:(id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer> (^)(NSArray<id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<VelocityexchangeverifiersKotlinKClass>)kClass serializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<VelocityexchangeverifiersKotlinKClass>)baseClass actualClass:(id<VelocityexchangeverifiersKotlinKClass>)actualClass actualSerializer:(id<VelocityexchangeverifiersKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<VelocityexchangeverifiersKotlinKClass>)baseClass defaultDeserializerProvider:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<VelocityexchangeverifiersKotlinKClass>)baseClass defaultDeserializerProvider:(id<VelocityexchangeverifiersKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<VelocityexchangeverifiersKotlinKClass>)baseClass defaultSerializerProvider:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol VelocityexchangeverifiersKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol VelocityexchangeverifiersKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol VelocityexchangeverifiersKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol VelocityexchangeverifiersKotlinKClass <VelocityexchangeverifiersKotlinKDeclarationContainer, VelocityexchangeverifiersKotlinKAnnotatedElement, VelocityexchangeverifiersKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonClassDiscriminatorMode")))
@interface VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode : VelocityexchangeverifiersKotlinEnum<VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *none __attribute__((swift_name("none")));
@property (class, readonly) VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *allJsonObjects __attribute__((swift_name("allJsonObjects")));
@property (class, readonly) VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *polymorphic __attribute__((swift_name("polymorphic")));
+ (VelocityexchangeverifiersKotlinArray<VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<VelocityexchangeverifiersKotlinx_serialization_jsonClassDiscriminatorMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol VelocityexchangeverifiersKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<VelocityexchangeverifiersKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
